class HomeController < ActionController::Base
  def index

  end
end

