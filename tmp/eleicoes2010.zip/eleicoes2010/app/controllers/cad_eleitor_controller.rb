class CadEleitorController < ApplicationController
end
