module SecaosHelper
end
