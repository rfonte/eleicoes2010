class CadEleitor < ActiveRecord::Base
end
