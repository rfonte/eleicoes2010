class Urna < ActiveRecord::Base
end
