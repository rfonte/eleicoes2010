class Candidato < ActiveRecord::Base
end
