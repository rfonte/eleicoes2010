class Partido < ActiveRecord::Base
end
